<center>
<script type="text/javascript">
    google_ad_client = "ca-pub-6338063578832547";
    google_ad_slot = "5073283314";
    google_ad_width = 728;
    google_ad_height = 90;
</script>
<!-- Header Ads -->
<script type="text/javascript"
src="//pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

</center>