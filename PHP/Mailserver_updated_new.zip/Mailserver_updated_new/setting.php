<a href="HomePage.php?chk=chngPass">change Password</a><br/>
<a href="HomePage.php?chk=chngthm">change Theme</a><br/>